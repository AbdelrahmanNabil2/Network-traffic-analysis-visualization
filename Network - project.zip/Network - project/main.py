import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.linear_model import LinearRegression
import networkx as nx
import numpy as np

# Load the dataset
file_path = 'Data.csv'
data = pd.read_csv(file_path, low_memory=False)

# Data Cleaning
data['Length'] = pd.to_numeric(data['Length'], errors='coerce')
data['No.'] = pd.to_numeric(data['No.'], errors='coerce')

# Drop rows with missing or invalid 'Length'
cleaned_data = data.dropna(subset=['Length'])

# Statistical Analysis
stats = {
    'Total Rows': len(cleaned_data),
    'Unique Protocols': cleaned_data['Protocol'].nunique(),
    'Unique Sources': cleaned_data['Source'].nunique(),
    'Unique Destinations': cleaned_data['Destination'].nunique(),
    'Mean Packet Length': cleaned_data['Length'].mean(),
    'Median Packet Length': cleaned_data['Length'].median(),
    'Max Packet Length': cleaned_data['Length'].max(),
    'Min Packet Length': cleaned_data['Length'].min(),
    'Variance of Packet Length': cleaned_data['Length'].var(),
    'Most Common Protocol': cleaned_data['Protocol'].mode()[0],
    'Most Frequent Source': cleaned_data['Source'].mode()[0],
    'Most Frequent Destination': cleaned_data['Destination'].mode()[0]
}

# Frequency Analysis
source_frequency = cleaned_data['Source'].value_counts()
destination_frequency = cleaned_data['Destination'].value_counts()
protocol_frequency = cleaned_data['Protocol'].value_counts()

# Calculate percentage for each frequency distribution
source_percentage = (source_frequency / len(cleaned_data)) * 100
destination_percentage = (destination_frequency / len(cleaned_data)) * 100
protocol_percentage = (protocol_frequency / len(cleaned_data)) * 100

# Additional Insights: Protocol-Length Relationship
protocol_length = cleaned_data.groupby('Protocol')['Length'].mean().sort_values(ascending=False)

# Linear Regression: Length vs No.
X = cleaned_data[['No.']].dropna()  # Independent variable
y = cleaned_data['Length'].loc[X.index]  # Dependent variable

# Initialize and fit the model
model = LinearRegression()
model.fit(X, y)

# Get the regression coefficients
slope = model.coef_[0]
intercept = model.intercept_
r_squared = model.score(X, y)

# Generate predictions for plotting the regression line
y_pred = model.predict(X)

# Save Statistical Insights to a Text File
with open('Statistical_Insights.txt', 'w') as file:
    file.write("Detailed Statistical Insights:\n")
    for key, value in stats.items():
        file.write(f"{key}: {value}\n")
    
    # Write Top 15 Source Frequency with percentages
    file.write("\nSource Frequency (Top 15):\n")
    for source, count in source_frequency.head(15).items():
        file.write(f"{source}: {count} ({source_percentage[source]:.2f}%)\n")
    
    # Write Top 15 Destination Frequency with percentages
    file.write("\nDestination Frequency (Top 15):\n")
    for destination, count in destination_frequency.head(15).items():
        file.write(f"{destination}: {count} ({destination_percentage[destination]:.2f}%)\n")
    
    # Write Top 15 Protocol Frequency with percentages
    file.write("\nProtocol Frequency (Top 15):\n")
    for protocol, count in protocol_frequency.head(15).items():
        file.write(f"{protocol}: {count} ({protocol_percentage[protocol]:.2f}%)\n")
    
    # Write Protocol-Length Relationship
    file.write("\n\nTop Protocols by Average Length:\n")
    file.write(protocol_length.to_string())
    
    # Write Top Source-Destination Pairs
    file.write("\n\nTop 15 Source-Destination Pairs:\n")
    source_dest_pairs = cleaned_data.groupby(['Source', 'Destination']).size().sort_values(ascending=False).head(15)
    file.write(source_dest_pairs.to_string())
    
    # Linear Regression Insights
    file.write("\n\nLinear Regression (Length vs No.):\n")
    file.write(f"Slope: {slope}\n")
    file.write(f"Intercept: {intercept}\n")
    file.write(f"R-squared: {r_squared}\n")

# Visualization

# 1. Histogram of Packet Length (Vertical)
plt.hist(cleaned_data['Length'], bins=30, color='blue', alpha=0.7)
plt.title('Packet Length Distribution')
plt.xlabel('Length')
plt.ylabel('Frequency')
plt.tight_layout()
plt.savefig('Packet_Length_Distribution.png')
plt.close()

# 2. Protocol-Length Relationship
sns.barplot(x=protocol_length.index, y=protocol_length.values, palette='coolwarm')
plt.title('Average Packet Length by Protocol')
plt.xlabel('Protocol')
plt.ylabel('Average Length')
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig('Average_Packet_Length_by_Protocol.png')
plt.close()

# 3. Top Destination Addresses
top_destinations = destination_frequency.head(15)
sns.barplot(x=top_destinations.values, y=top_destinations.index, palette='muted')
plt.title('Top 15 Destinations')
plt.xlabel('Count')
plt.ylabel('Destination')
plt.tight_layout()
plt.savefig('Top_15_Destinations.png')
plt.close()

# 4. Source Frequency
top_sources = source_frequency.head(15)
sns.barplot(x=top_sources.values, y=top_sources.index, palette='viridis')
plt.title('Top 15 Source Frequencies')
plt.xlabel('Frequency')
plt.ylabel('Source')
plt.tight_layout()
plt.savefig('Top_15_Source_Frequencies.png')
plt.close()

# 5. Protocol Frequency
top_protocols = protocol_frequency.head(15)
sns.barplot(x=top_protocols.values, y=top_protocols.index, palette='pastel')
plt.title('Top 15 Protocol Frequencies')
plt.xlabel('Frequency')
plt.ylabel('Protocol')
plt.tight_layout()
plt.savefig('Top_15_Protocol_Frequencies.png')
plt.close()

# 6. Protocol Frequency Pie Chart (Top 5)
protocol_pie = protocol_frequency.head(5)
plt.pie(protocol_pie.values, labels=protocol_pie.index, autopct='%1.1f%%', colors=sns.color_palette('pastel'))
plt.title('Protocol Frequency Distribution (Top 5)')
plt.tight_layout()
plt.savefig('Protocol_Frequency_Distribution_Pie.png')
plt.close()

# 7. Linear Regression Plot (Length vs No.)
plt.figure(figsize=(8, 6))
plt.scatter(X, y, color='blue', alpha=0.5, label='Data Points')  # Plot the actual data points
plt.plot(X, y_pred, color='red', label=f'Regression Line: y = {slope:.2f}x + {intercept:.2f}')  # Regression line

# Display R-squared value on the plot
plt.text(0.05, 0.95, f"R-squared = {r_squared:.2f}", transform=plt.gca().transAxes, fontsize=12, verticalalignment='top')

# Adding grid, labels, and title for better readability
plt.grid(True)
plt.title('Linear Regression: Length vs No.')
plt.xlabel('No.')
plt.ylabel('Length')
plt.legend(loc='best')
plt.tight_layout()

# Save the plot
plt.savefig('Enhanced_Linear_Regression_Length_vs_No.png')
plt.close()

# 8. Network Graph: Source-Destination Relationships
# Create a NetworkX graph
G = nx.from_pandas_edgelist(cleaned_data, 'Source', 'Destination', create_using=nx.Graph())

# Degree centrality can be used to size the nodes based on frequency of connection
degree_centrality = nx.degree_centrality(G)

# Color the edges by frequency (weight), and node size by degree centrality
node_size = [v * 1000 for v in degree_centrality.values()]  # Scale node size by degree centrality
edge_color = [G[u][v].get('weight', 1) for u, v in G.edges()]

# Plot the graph
plt.figure(figsize=(12, 12))
pos = nx.spring_layout(G, k=0.15, iterations=30)  # Force-directed layout for better spread

# Draw nodes and edges
nx.draw_networkx_nodes(G, pos, node_size=node_size, node_color='skyblue', alpha=0.7)
nx.draw_networkx_edges(G, pos, width=1.0, alpha=0.5, edge_color='gray')
nx.draw_networkx_labels(G, pos, font_size=10, font_color='black')

# Add title and grid for clarity
plt.title('Enhanced Network Graph: Source-Destination Relationships')
plt.grid(True)
plt.tight_layout()

# Save the plot
plt.savefig('Enhanced_Network_Graph_Source_Destination.png')
plt.close()

# 9. Scatter Plot: Packet Length vs No.
plt.figure(figsize=(8, 6))

# Scatter plot for the actual data points
plt.scatter(cleaned_data['No.'], cleaned_data['Length'], color='green', alpha=0.5, label='Data Points')

# Plot the regression line on top of the scatter plot
plt.plot(X, y_pred, color='red', label=f'Regression Line: y = {slope:.2f}x + {intercept:.2f}')

# Adding grid, labels, and title for better readability
plt.grid(True)
plt.title('Enhanced Scatter Plot: Packet Length vs No.')
plt.xlabel('No.')
plt.ylabel('Packet Length')
plt.legend(loc='best')

# Save the plot
plt.tight_layout()
plt.savefig('Enhanced_Scatter_Plot_Length_vs_No.png')
plt.close()
