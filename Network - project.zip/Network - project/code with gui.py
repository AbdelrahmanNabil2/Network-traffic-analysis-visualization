import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.linear_model import LinearRegression
import tkinter as tk
from tkinter import filedialog, messagebox
from tkinter import ttk
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from scapy.all import rdpcap, Raw
import chardet
import networkx as nx

# GUI Class
class DataAnalysisApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Network Traffic Data Analysis")
        self.root.geometry("1200x800")  # Increased size to make it spacious
        
        self.data = None
        self.cleaned_data = None
        self.figures = []
        
        # Create UI Elements
        self.create_widgets()
    
    def create_widgets(self):
        # File Upload Section
        upload_frame = tk.Frame(self.root, pady=10)
        upload_frame.pack(fill=tk.X)
        tk.Button(upload_frame, text="Upload File (CSV/XLSX/PCAP)", command=self.upload_file, bg="blue", fg="black", font=("Arial", 12)).pack()
        
        # Output Sections (Increased size)
        self.stats_text = tk.Text(self.root, height=15, width=100, wrap=tk.WORD, font=("Courier New", 10))
        self.stats_text.pack(pady=10)
        self.stats_text.insert(tk.END, "Upload a file to see the analysis results here.")
        self.stats_text.config(state=tk.DISABLED)
        
        # Navigation Section (Buttons for moving between charts)
        nav_frame = tk.Frame(self.root)
        nav_frame.pack(fill=tk.X)
        
        self.prev_button = tk.Button(nav_frame, text="Previous Chart", command=self.show_previous_chart, state=tk.DISABLED, bg="gray", fg="black", font=("Arial", 12))
        self.prev_button.pack(side=tk.LEFT, padx=10)
        
        self.next_button = tk.Button(nav_frame, text="Next Chart", command=self.show_next_chart, state=tk.DISABLED, bg="blue", fg="black", font=("Arial", 12))
        self.next_button.pack(side=tk.LEFT)
        
        # Visualization Tabs (Using Notebook for tab navigation)
        self.tab_control = ttk.Notebook(self.root)
        self.charts_tab = tk.Frame(self.tab_control)
        self.tab_control.add(self.charts_tab, text="Charts")
        self.tab_control.pack(expand=1, fill="both")
        
        # Frame for Charts (Increase the height of the chart area)
        self.canvas_frame = tk.Frame(self.charts_tab, height=600)
        self.canvas_frame.pack(fill=tk.BOTH, expand=True)
    
    def detect_encoding(self, file_path):
        with open(file_path, 'rb') as file:
            result = chardet.detect(file.read())
        return result['encoding']
    
    def upload_file(self):
        file_path = filedialog.askopenfilename(filetypes=[("All Files", "*.*"), ("CSV Files", "*.csv"), ("Excel Files", "*.xlsx"), ("PCAP Files", "*.pcap")])
        if file_path:
            try:
                if file_path.endswith('.csv'):
                    encoding = self.detect_encoding(file_path)
                    self.data = pd.read_csv(file_path, low_memory=False, encoding=encoding)
                elif file_path.endswith('.xlsx'):
                    self.data = pd.read_excel(file_path, engine='openpyxl')
                elif file_path.endswith('.pcap'):
                    self.data = self.parse_pcap(file_path)
                else:
                    raise ValueError("Unsupported file format.")
                
                self.perform_analysis()
                messagebox.showinfo("Success", "File successfully loaded and analyzed!")
            except Exception as e:
                messagebox.showerror("Error", f"Failed to load file: {e}")
    
    def parse_pcap(self, file_path):
        packets = rdpcap(file_path)
        rows = []
        for packet in packets:
            row = {
                'Source': packet[0].src if hasattr(packet[0], 'src') else None,
                'Destination': packet[0].dst if hasattr(packet[0], 'dst') else None,
                'Protocol': packet[0].name if hasattr(packet[0], 'name') else None,
                'Length': len(packet),
                'No.': packets.index(packet) + 1
            }
            rows.append(row)
        return pd.DataFrame(rows)
    
    def perform_analysis(self):
        # Data Cleaning
        self.data['Length'] = pd.to_numeric(self.data['Length'], errors='coerce')
        self.data['No.'] = pd.to_numeric(self.data['No.'], errors='coerce')
        self.cleaned_data = self.data.dropna(subset=['Length'])
        
        # Statistical Analysis
        stats = {
            'Total Rows': len(self.cleaned_data),
            'Unique Protocols': self.cleaned_data['Protocol'].nunique(),
            'Unique Sources': self.cleaned_data['Source'].nunique(),
            'Unique Destinations': self.cleaned_data['Destination'].nunique(),
            'Mean Packet Length': self.cleaned_data['Length'].mean(),
            'Median Packet Length': self.cleaned_data['Length'].median(),
            'Max Packet Length': self.cleaned_data['Length'].max(),
            'Min Packet Length': self.cleaned_data['Length'].min(),
            'Variance of Packet Length': self.cleaned_data['Length'].var(),
            'Most Common Protocol': self.cleaned_data['Protocol'].mode()[0] if not self.cleaned_data['Protocol'].isnull().all() else 'N/A',
            'Most Frequent Source': self.cleaned_data['Source'].mode()[0] if not self.cleaned_data['Source'].isnull().all() else 'N/A',
            'Most Frequent Destination': self.cleaned_data['Destination'].mode()[0] if not self.cleaned_data['Destination'].isnull().all() else 'N/A'
        }
        
        # Update Statistics Text with Percentage for Top 15
        self.stats_text.config(state=tk.NORMAL)
        self.stats_text.delete(1.0, tk.END)
        
        # Show Raw Counts
        for key, value in stats.items():
            self.stats_text.insert(tk.END, f"{key}: {value}\n")

        # Add percentage for top 15 protocols
        self.stats_text.insert(tk.END, "\nTop 15 Protocols:\n")
        protocol_frequency = self.cleaned_data['Protocol'].value_counts().head(15)
        for protocol, count in protocol_frequency.items():
            percentage = (count / len(self.cleaned_data)) * 100
            self.stats_text.insert(tk.END, f"{protocol}: {count} ({percentage:.2f}%)\n")

        # Add percentage for top 15 sources
        self.stats_text.insert(tk.END, "\nTop 15 Sources:\n")
        source_frequency = self.cleaned_data['Source'].value_counts().head(15)
        for src, count in source_frequency.items():
            percentage = (count / len(self.cleaned_data)) * 100
            self.stats_text.insert(tk.END, f"{src}: {count} ({percentage:.2f}%)\n")
        # Add percentage for top 15 destinations
        self.stats_text.insert(tk.END, "\nTop 15 Destinations:\n")
        destination_frequency = self.cleaned_data['Destination'].value_counts().head(15)
        for dest, count in destination_frequency.items():
            percentage = (count / len(self.cleaned_data)) * 100
            self.stats_text.insert(tk.END, f"{dest}: {count} ({percentage:.2f}%)\n")
        
        
        
        
        
        self.stats_text.config(state=tk.DISABLED)
        
        # Generate Charts
        self.generate_charts()
    
    def generate_charts(self):
        for widget in self.canvas_frame.winfo_children():
            widget.destroy()
        
        self.figures = []
        
        # 1. Histogram of Packet Length
        fig1 = plt.Figure(figsize=(10, 6), dpi=100)  # Increased size for better display
        ax1 = fig1.add_subplot(111)
        self.cleaned_data['Length'].plot(kind='hist', bins=30, color='blue', alpha=0.7, ax=ax1)
        ax1.set_title('Packet Length Distribution')
        ax1.set_xlabel('Length')
        ax1.set_ylabel('Frequency')
        self.add_chart(fig1)
        
        # 2. Protocol-Length Relationship
        protocol_length = self.cleaned_data.groupby('Protocol')['Length'].mean().sort_values(ascending=False)
        fig2 = plt.Figure(figsize=(10, 6), dpi=100)
        ax2 = fig2.add_subplot(111)
        sns.barplot(x=protocol_length.index, y=protocol_length.values, ax=ax2, palette='coolwarm')
        ax2.set_title('Average Packet Length by Protocol')
        ax2.set_xlabel('Protocol')
        ax2.set_ylabel('Average Length')
        ax2.tick_params(axis='x', rotation=45)
        self.add_chart(fig2)
        
        # 3. Top Destination Addresses
        destination_frequency = self.cleaned_data['Destination'].value_counts()
        fig3 = plt.Figure(figsize=(10, 6), dpi=100)
        ax3 = fig3.add_subplot(111)
        sns.barplot(x=destination_frequency.head(15).values, y=destination_frequency.head(15).index, ax=ax3, palette='muted')
        ax3.set_title('Top 15 Destinations')
        ax3.set_xlabel('Count')
        ax3.set_ylabel('Destination')
        self.add_chart(fig3)
        
        # 4. Source Frequency
        source_frequency = self.cleaned_data['Source'].value_counts()
        fig4 = plt.Figure(figsize=(10, 6), dpi=100)
        ax4 = fig4.add_subplot(111)
        sns.barplot(x=source_frequency.head(15).values, y=source_frequency.head(15).index, ax=ax4, palette='viridis')
        ax4.set_title('Top 15 Source Frequencies')
        ax4.set_xlabel('Frequency')
        ax4.set_ylabel('Source')
        self.add_chart(fig4)
        
        # 5. Protocol Frequency
        protocol_frequency = self.cleaned_data['Protocol'].value_counts()
        fig5 = plt.Figure(figsize=(10, 6), dpi=100)
        ax5 = fig5.add_subplot(111)
        sns.barplot(x=protocol_frequency.head(15).values, y=protocol_frequency.head(15).index, ax=ax5, palette='pastel')
        ax5.set_title('Top 15 Protocol Frequencies')
        ax5.set_xlabel('Frequency')
        ax5.set_ylabel('Protocol')
        self.add_chart(fig5)
        
        # 6. Protocol Frequency Pie Chart (Top 5)
        protocol_pie = protocol_frequency.head(5)
        fig6 = plt.Figure(figsize=(10, 6), dpi=100)
        ax6 = fig6.add_subplot(111)
        ax6.pie(protocol_pie.values, labels=protocol_pie.index, autopct='%1.1f%%', colors=sns.color_palette('pastel'))
        ax6.set_title('Protocol Frequency Distribution (Top 5)')
        self.add_chart(fig6)
        
        # 7. Linear Regression Plot (Length vs No.)
        X = self.cleaned_data[['No.']].dropna()
        y = self.cleaned_data['Length'].loc[X.index]
        model = LinearRegression()
        model.fit(X, y)
        y_pred = model.predict(X)
        
        fig7 = plt.Figure(figsize=(10, 6), dpi=100)
        ax7 = fig7.add_subplot(111)
        ax7.scatter(X, y, color='blue', alpha=0.5, label='Data Points')
        ax7.plot(X, y_pred, color='red', label=f'Regression Line')
        ax7.set_title('Linear Regression: Length vs No.')
        ax7.set_xlabel('No.')
        ax7.set_ylabel('Length')
        ax7.legend(loc='best')
        self.add_chart(fig7)
        
        # 8. Network Graph: Source-Destination Relationships
        top_sources = self.cleaned_data['Source'].value_counts().head(10).index
        top_destinations = self.cleaned_data['Destination'].value_counts().head(10).index
        filtered_data = self.cleaned_data[
     self.cleaned_data['Source'].isin(top_sources) | self.cleaned_data['Destination'].isin(top_destinations)
]
        G = nx.from_pandas_edgelist(filtered_data, 'Source', 'Destination', create_using=nx.Graph())
        degree_centrality = nx.degree_centrality(G)
        node_size = [v * 5000 for v in degree_centrality.values()]
        fig8 = plt.Figure(figsize=(10, 6), dpi=100)
        ax8 = fig8.add_subplot(111)
        pos = nx.spring_layout(G, k=0.2, iterations=50)
        nx.draw_networkx_nodes(G, pos, node_size=node_size, node_color='skyblue', alpha=0.8, ax=ax8)
        nx.draw_networkx_edges(G, pos, width=1.5, alpha=0.6, edge_color='gray', ax=ax8)
        top_nodes = list(top_sources) + list(top_destinations)
        labels = {node: node for node in G.nodes if node in top_nodes}
        nx.draw_networkx_labels(G, pos, labels=labels, font_size=10, ax=ax8)
        ax8.set_title('Simplified Source-Destination Network Graph')
        self.add_chart(fig8)
        # 9. Scatter Plot: Source vs Average Packet Length (Top 20)
        source_length_summary = self.cleaned_data.groupby('Source')['Length'].mean().sort_values(ascending=False).head(20)
        fig9 = plt.Figure(figsize=(10, 6), dpi=100)
        ax9 = fig9.add_subplot(111)
        sns.scatterplot(x=source_length_summary.index, y=source_length_summary.values, ax=ax9, color='green', s=100)
        ax9.set_title('Scatter Plot: Source vs Average Packet Length (Top 20)')
        ax9.set_xlabel('Source')
        ax9.set_ylabel('Average Packet Length')
        ax9.tick_params(axis='x', rotation=45)
        self.add_chart(fig9)
        
        self.current_chart = 0
        self.update_navigation_buttons()
    
    def add_chart(self, fig):
        canvas = FigureCanvasTkAgg(fig, self.canvas_frame)
        canvas_widget = canvas.get_tk_widget()
        canvas_widget.pack(fill=tk.BOTH, expand=True, pady=10)
        canvas.draw()
        self.figures.append(fig)
    
    def update_navigation_buttons(self):
        if len(self.figures) > 1:
            self.prev_button.config(state=tk.NORMAL)
            self.next_button.config(state=tk.NORMAL)
        else:
            self.prev_button.config(state=tk.DISABLED)
            self.next_button.config(state=tk.DISABLED)

    def show_previous_chart(self):
        if self.current_chart > 0:
            self.current_chart -= 1
            self.update_displayed_chart()
    
    def show_next_chart(self):
        if self.current_chart < len(self.figures) - 1:
            self.current_chart += 1
            self.update_displayed_chart()
    
    def update_displayed_chart(self):
        # Clear current chart display
        for widget in self.canvas_frame.winfo_children():
            widget.destroy()
        
        # Display the selected chart
        self.add_chart(self.figures[self.current_chart])
        self.update_navigation_buttons()

# Main Execution
if __name__ == "__main__":
    root = tk.Tk()
    app = DataAnalysisApp(root)
    root.mainloop()
